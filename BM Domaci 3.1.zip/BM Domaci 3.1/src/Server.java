import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Base64;

public class Server {

    private SecretKey desKey;

    public Server() throws Exception {
        ServerSocket serverSocket = new ServerSocket(2025);
        Socket socket = serverSocket.accept();

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);


        generateAndStoreDESKey();


        out.println("Welcome, enter your password to continue:");
        while(true) {

        String encryptedPassword = in.readLine();



            if (decryptDESAndCheckPassword(encryptedPassword)) {
                out.println("Congratulations, you can start chatting:");

                startAESCommunication(socket);
                break;
            } else {
                out.println("Invalid password, please try again:");

            }
        }
        socket.close();
    }

    private void generateAndStoreDESKey() throws Exception {

        KeyGenerator keyGenerator = KeyGenerator.getInstance("DES");
        keyGenerator.init(56);
        desKey = keyGenerator.generateKey();


        FileOutputStream fos = new FileOutputStream("DESKEYS.key");
        fos.write(desKey.getEncoded());
        fos.flush();
        fos.close();
    }

    private boolean decryptDESAndCheckPassword(String encryptedPassword) throws Exception {

        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.DECRYPT_MODE, desKey);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));

        
        String password = new String(decryptedBytes);
        return password.equals("RAFSecurity");
    }

    private void startAESCommunication(Socket socket) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

        SecretKey key = generiseAESkljuc();

        FileOutputStream fos = new FileOutputStream("Kljuc.key");
        fos.write(key.getEncoded());
        fos.flush();
        fos.close();

        out.println("Dobrodosli");

        while (true) {
            String poruka = in.readLine();
            System.out.println("Klijent: " + poruka); // prikaz enkriptovane poruke

            String dekPoruka = decryptAES(poruka, key);
            System.out.println("Klient: " + dekPoruka); // prikaz dekriptovane poruke

            if (dekPoruka.equals("EXIT")){
                System.out.println("Prekinuta komunikacija sa klijentske strane");
                break;
            }else { // ovaj deo sluzi kako bi server poslao poruku klijentu
                System.out.println("Unesite poruku: ");
                String serPoruka = tin.readLine();

                String enkPoruka = encyptAES(serPoruka, key);
                out.println(enkPoruka);

                if(serPoruka.equals("EXIT")){
                    System.out.println("Prekinuta komunikacija sa serverske strane");
                    break;
                }
            }
        }
    }

    private SecretKey generiseAESkljuc() throws Exception{

        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128);
        SecretKey kljuc = keyGenerator.generateKey();

        return kljuc;
    }

    private String decryptAES(String sifrovan, SecretKey key) throws Exception{
        // Korak 1
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] sifrovanBytes = decoder.decode(sifrovan);

        // Korak 2
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] dekriptovanBytes = cipher.doFinal(sifrovanBytes);

        // Korak 3
        return new String(dekriptovanBytes);
    }

    private String encyptAES(String tekst, SecretKey key) throws Exception{
        // Korak 1
        byte[] tekstBytes = tekst.getBytes();

        // Korak 2
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] enkripovanBytes = cipher.doFinal(tekstBytes);

        // Korak 3
        Base64.Encoder encoder = Base64.getEncoder();
        String enkriptovan = encoder.encodeToString(enkripovanBytes);

        return enkriptovan;
    }

    public static void main(String[] args) throws Exception {
        new Server();
    }
}
