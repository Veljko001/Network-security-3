import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.Socket;
import java.util.Base64;

public class Client {

    public Client() throws Exception {
        Socket socket = new Socket("localhost", 2025);

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);


        System.out.println(in.readLine());


        SecretKeySpec desKey = readDESKeyFromFile();



        while(true) {

            String password = tin.readLine();
            String encryptedPassword = encryptDES(password, desKey);
            out.println(encryptedPassword);


            String response = in.readLine();
            System.out.println(response);

            if (response.equals("Congratulations, you can start chatting:")) {
                startAESCommunication(socket);
                break;
            }
        }


        socket.close();
    }

    private SecretKeySpec readDESKeyFromFile() throws Exception {
        File file = new File("DESKEYS.key");
        FileInputStream fis = new FileInputStream(file);
        byte[] encodedKey = new byte[(int) file.length()];
        fis.read(encodedKey);
        fis.close();
        return new SecretKeySpec(encodedKey, "DES");
    }

    private String encryptDES(String plaintext, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedBytes = cipher.doFinal(plaintext.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    private void startAESCommunication(Socket socket) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

        System.out.println(in.readLine()); // ocekivana poruka Dobrodoslice

        File file = new File("Kljuc.key");
        long size = file.length();
        FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[(int) size];
        fis.read(buffer);
        fis.close();

        SecretKeySpec key = new SecretKeySpec(buffer, "AES");

        while (true) {
            System.out.println("Unesite tekst za slanje: ");
            String tekst = tin.readLine();

            String enTekst = encyptAES(tekst, key);
            out.println(enTekst);

            if (tekst.equals("EXIT")){
                System.out.println("Prekinuta komunikacija sa strane klijenta");
                break;
            }

            String serPoruka = in.readLine();
            String dekPoruka = decryptAES(serPoruka, key);

            if(dekPoruka.equals("EXIT")){
                System.out.println("Prekinuta komunikacija sa strane servera");
                break;
            } else {
                System.out.println("Server: " + serPoruka); // enk ser poruka
                System.out.println("Server: " + dekPoruka);
            }

        }
    }

    private String decryptAES(String sifrovan, SecretKey key) throws Exception{
        // Korak 1
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] sifrovanBytes = decoder.decode(sifrovan);

        // Korak 2
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] dekriptovanBytes = cipher.doFinal(sifrovanBytes);

        // Korak 3
        return new String(dekriptovanBytes);
    }

    private String encyptAES(String tekst, SecretKey key) throws Exception{
        // Korak 1
        byte[] tekstBytes = tekst.getBytes();

        // Korak 2
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] enkripovanBytes = cipher.doFinal(tekstBytes);

        // Korak 3
        Base64.Encoder encoder = Base64.getEncoder();
        String enkriptovan = encoder.encodeToString(enkripovanBytes);

        return enkriptovan;
    }

    public static void main(String[] args) throws Exception {
        new Client();
    }
}
